#!/bin/bash

DEMO=0

set -euo pipefail

black='\E[30;40m'
red='\E[31;40m'
green='\E[32;40m'
yellow='\E[33;40m'
blue='\E[34;40m'
magenta='\E[35;40m'
cyan='\E[36;40m'
white='\E[37;40m'
reset='\033[00m'

cecho () {
    local default_msg="No message passed."

    message=${1:-$default_msg}
    color=${2:-$black}

    echo -e "$color"
    echo -e "$message"
    tput sgr0

    return
}

unset VMC_VCENTER_PASSWORD
unset CHARCOUNT
unset PROMPT

cecho "Enter the following variables required for deployment:" $cyan

echo -e "${magenta}"
read -p "VMC vCenter Server FQDN: "  VMC_VCENTER
if [[ -z "${VMC_VCENTER}" ]]; then
    cecho "Please start over. No input entered." $red
    exit 1
fi

echo -e "${magenta}"
echo -n "VMC vCenter Server Password: "
read -s VMC_VCENTER_PASSWORD
if [[ -z "${VMC_VCENTER_PASSWORD}" ]]; then
    cecho "Please start over. No input entered." $red
    exit 1
fi
echo ""

echo -e "${magenta}"
echo -n "OpenFaaS Admin Password: "
read -s OPENFAAS_PASSWORD
if [[ -z "${OPENFAAS_PASSWORD}" ]]; then
    cecho "Please start over. No input entered." $red
    exit 1
fi
echo ""

echo -e "${magenta}"
read -p "VMC vCenter Server vSphere Tag ID: "  VMC_TAG_ID
if [[ -z "${VMC_TAG_ID}" ]]; then
    cecho "Please start over. No input entered." $red
    exit 1
fi

cecho "Please confirm the following settings are correct:\n" $cyan
echo -e "\tVMC_VCENTER=${VMC_VCENTER}"
if [ $DEMO -eq 1 ]; then
    echo -e "\tVMC_VCENTER_PASSWORD=*********"
    echo -e "\tOPENFAAS_PASSWORD=*********"
else
    echo -e "\tVMC_VCENTER_PASSWORD=${VMC_VCENTER_PASSWORD}"
    echo -e "\tOPENFAAS_PASSWORD=${OPENFAAS_PASSWORD}"
fi
echo -e "\tVMC_TAG_ID=${VMC_TAG_ID}"

echo -e "${cyan}"
read -p "Would you like to begin deployment of VEBA K8s Application [Y]: " question
if [[ ${question} != "Y" ]]; then
    cecho "Existing ..." ${red}
    exit
fi

cecho "Creating vmware namespace" $green
echo -e "\tkubectl create namespace vmware"
kubectl create namespace vmware

cecho "Deploying OpenFaaS" $green
echo -e "\tkubectl create -f faas-netes/namespaces.yml"
echo -e "\tkubectl -n openfaas create secret generic basic-auth --from-literal=basic-auth-user=admin --from-literal=basic-auth-password=${OPENFAAS_PASSWORD}"
echo -e "\tkubectl create -f faas-netes/yaml"
kubectl create -f faas-netes/namespaces.yml
kubectl -n openfaas create secret generic basic-auth --from-literal=basic-auth-user=admin --from-literal=basic-auth-password="${OPENFAAS_PASSWORD}"
kubectl create -f faas-netes/yaml

OPENFAAS_GATEWAY=$(kubectl -n openfaas describe pods $(kubectl -n openfaas get pods | grep "gateway-" | awk '{print $1}') | grep "^Node:" | awk -F "/" '{print $2}')
while [ 1 ];
do
    cecho "Waiting for OpenFaaS to be ready ..." $green
    OPENFAAS_GATEWAY=$(kubectl -n openfaas describe pods $(kubectl -n openfaas get pods | grep "gateway-" | awk '{print $1}') | grep "^Node:" | awk -F "/" '{print $2}')
    if [ ! -z ${OPENFAAS_GATEWAY} ]; then
        break
    fi
done

cecho "Creating VEBA deployment files..." $green
cat > /root/demo/veba/event-router-config.json << EOF
[{
        "type": "stream",
        "provider": "vmware_vcenter",
        "address": "https://${VMC_VCENTER}:443/sdk",
        "auth": {
            "method": "user_password",
            "secret": {
                "username": "cloudadmin@vmc.local",
                "password": "${VMC_VCENTER_PASSWORD}"
            }
        },
        "options": {
            "insecure": "true"
        }
    },
    {
        "type": "processor",
        "provider": "openfaas",
        "address": "http://gateway.openfaas:8080",
        "auth": {
            "method": "basic_auth",
            "secret": {
                "username": "admin",
                "password": "${OPENFAAS_PASSWORD}"
            }
        },
        "options": {
            "async": "false"
        }
    },
    {
        "type": "metrics",
        "provider": "internal",
        "address": "0.0.0.0:8080",
        "auth": {
            "method": "none"
        }
    }
]
EOF

cat > /root/demo/veba/event-router-k8s.yaml << __EVENT_ROUTER_CONFIG
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app: vmware-event-router
  name: vmware-event-router
spec:
  replicas: 1
  selector:
    matchLabels:
      app: vmware-event-router
  template:
    metadata:
      labels:
        app: vmware-event-router
    spec:
      containers:
      - image: vmware/veba-event-router:latest
        args: ["-config", "/etc/vmware-event-router/event-router-config.json", "-verbose"]
        name: vmware-event-router
        resources:
          requests:
            cpu: 200m
            memory: 200Mi
        volumeMounts:
        - name: config
          mountPath: /etc/vmware-event-router/
          readOnly: true
      volumes:
      - name: config
        secret:
          secretName: event-router-config
---
apiVersion: v1
kind: Service
metadata:
  labels:
    app: vmware-event-router
  name: vmware-event-router
spec:
  ports:
  - port: 8080
    protocol: TCP
    targetPort: 8080
  selector:
    app: vmware-event-router
  sessionAffinity: None
__EVENT_ROUTER_CONFIG

cat > /root/demo/veba/vcconfig.toml << EOF
[vcenter]
server = "${VMC_VCENTER}"
user = "cloudadmin@vmc.local"
password = "${VMC_VCENTER_PASSWORD}"

[tag]
urn = "${VMC_TAG_ID}"
action = "attach"
EOF

cat > /root/demo/veba/stack.yml << EOF
provider:
  name: openfaas
  gateway: http://${OPENFAAS_GATEWAY}:31112
functions:
  pytag-fn:
    lang: python3
    handler: ./handler
    image: vmware/veba-python-tagging:latest
    environment:
      write_debug: true
      read_debug: true
    secrets:
      - vcconfig
    annotations:
      topic: DrsVmPoweredOnEvent
EOF

cecho "Deploying VMware Event Router ..." $green
echo -e "\tkubectl -n vmware create secret generic event-router-config --from-file=event-router-config.json"
echo -e "\tkubectl -n vmware create -f event-router-k8s.yaml"
kubectl -n vmware create secret generic event-router-config --from-file=event-router-config.json
kubectl -n vmware create -f event-router-k8s.yaml

cecho "Exporting OpenFaaS URL variable ..." $green
OPENFAAS_URL=${OPENFAAS_GATEWAY}:31112
export OPENFAAS_URL=${OPENFAAS_GATEWAY}:31112
echo -e "\tOPENFAAS_URL=${OPENFAAS_GATEWAY}:31112"

## DEBUG
echo "export OPENFAAS_URL=${OPENFAAS_GATEWAY}:31112" >> debug.txt
echo "export OPENFAAS_PASSWORD=${OPENFAAS_PASSWORD}" >> debug.txt
echo "echo -n \$OPENFAAS_PASSWORD | faas-cli login --password-stdin" >> debug.txt
echo "faas-cli secret create vcconfig --from-file=vcconfig.toml --tls-no-verify" >> debug.txt
echo "faas-cli deploy -f stack.yml --tls-no-verify" >> debug.txt

cecho "Waiting for OpenFaaS to be ready ..." $green
echo -e "\tfaas-cli login --password-stdin"

while [ 1 ];
do
    sleep 15
    echo -n $OPENFAAS_PASSWORD | faas-cli login --password-stdin > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        cecho "Successfully logged into OpenFaaS ..." $green
        break
    fi
done

cecho "Deploying vSphere Taggign Function ..." $green
echo -e "\tfaas-cli secret create vcconfig --from-file=vcconfig.toml --tls-no-verify"
echo -e "\tfaas-cli deploy -f stack.yml --tls-no-verify"
faas-cli secret create vcconfig --from-file=vcconfig.toml --tls-no-verify
faas-cli deploy -f stack.yml --tls-no-verify