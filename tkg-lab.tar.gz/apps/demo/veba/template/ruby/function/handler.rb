class Handler
  def run(req)
    return "Hello world from the Ruby template"
  end
end
