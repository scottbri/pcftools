#!/bin/bash

kubectl -n vmware delete -f event-router-k8s.yaml
rm -f event-router-config.json
rm -f event-router-k8s.yaml
rm -f stack.yml
rm -f vcconfig.toml 
kubectl delete -f faas-netes/yaml
kubectl delete ns vmware
kubectl delete ns openfaas
kubectl delete ns openfaas-fn
