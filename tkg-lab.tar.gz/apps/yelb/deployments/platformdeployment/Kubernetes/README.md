These configurations had been tested against a local minikube setup.

Ideally they should / could be broken into independent configurations for any given module of the app and composed properly at deployment time. 

This is a work in progress.
