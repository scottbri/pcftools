export const environment = {
  production: false,
  envName: 'test',
  appserver_env: 'http://localhost:4567'
};
