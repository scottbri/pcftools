#!/bin/bash

set -euo pipefail

rm -rf ~/.tkg
tkg get management-cluster
cat tkg/vsphere.yaml >> .tkg/config.yaml
##sed command needed to replace cloneMode: fullClone with cloneMode: linkedClone in dev/prod templ.
tkg init -i vsphere -p dev --name tkg-mgmt
tkg create cluster my-cluster -p dev --kubernetes-version v1.17.3+vmware.2 -c 1 -w 3
tkg get credentials my-cluster
kubectl apply -f tkg/storageclass.yaml
kubectl create ns metallb-system
kubectl apply -f https://raw.githubusercontent.com/google/metallb/v0.9.2/manifests/metallb.yaml -n metallb-system
kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)"
kubectl apply -f tkg/metallb-configmap.yaml
sleep 60
kubectl create deployment echo --image=inanimate/echo-server
kubectl scale deployment echo --replicas=3
kubectl expose deployment echo --port=8080 --type LoadBalancer
kubectl apply -f https://projectcontour.io/quickstart/contour.yaml
sleep 60
kubectl apply -f https://projectcontour.io/examples/kuard.yaml
