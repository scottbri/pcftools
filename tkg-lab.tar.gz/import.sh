#!/bin/bash

set -euo pipefail

NETWORK=VM-RegionA01-vDS-COMP
PHOTON=photon-3-v1.17.3+vmware.2
HAPROXY=photon-3-capv-haproxy-v0.6.3+vmware.1

cd /home/ubuntu/tkg

govc import.spec ${HAPROXY}.ova | jq ".Name=\"$HAPROXY\"" | jq ".NetworkMapping[0].Network=\"$NETWORK\"" > ${HAPROXY}.json
govc import.ova -options=${HAPROXY}.json ${HAPROXY}.ova
govc object.mv /RegionA01/vm/${HAPROXY} /RegionA01/vm/tkg
govc snapshot.create -vm ${HAPROXY} root
govc vm.markastemplate ${HAPROXY}

govc import.spec ${PHOTON}.ova | jq ".Name=\"$PHOTON\"" | jq ".NetworkMapping[0].Network=\"$NETWORK\"" > ${PHOTON}.json
govc import.ova -options=${PHOTON}.json ${PHOTON}.ova
govc object.mv /RegionA01/vm/${PHOTON} /RegionA01/vm/tkg
govc snapshot.create -vm ${PHOTON} root
govc vm.markastemplate ${PHOTON}
